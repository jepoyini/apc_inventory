<?php

// namespace App\Helpers;

// class AuthHelper
// {
//     private static $authUser = null;

//     public static function setAuthUser($user)
//     {
//         self::$authUser = $user;
//     }

//     public static function getAuthUser()
//     {
//         return self::$authUser;
//     }


}